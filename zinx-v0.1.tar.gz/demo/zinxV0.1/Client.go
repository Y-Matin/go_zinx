package main

import (
	"bufio"
	"bytes"
	"fmt"
	"net"
	"os"
	"time"
)

func main() {
	conn, err := net.Dial("tcp", "127.0.0.1:8999")
	if err != nil {
		fmt.Println("[client] connect  to server error: ",err)
	}else{
		fmt.Println("[client] connect server success")
	}
	reader := bufio.NewReader(os.Stdin)
	defer conn.Close()
	data:= make([]byte,128)

	for true {
		msgByte, err := reader.ReadBytes('\n')
		//msgByte:= []byte("jkdsknb看过了你的反馈你看")
		if bytes.Equal(msgByte, []byte("exit")) {
			break
		}

		_, err = conn.Write(msgByte)
		if err != nil {
			fmt.Println("send msg to server error:", err)
		}

		read, err := conn.Read(data)
		if err!=nil {
			fmt.Println("read msg from server error:",err)
		}else {
			fmt.Println(string(data[0:read]))
		}
		time.Sleep(time.Second)
	}

}